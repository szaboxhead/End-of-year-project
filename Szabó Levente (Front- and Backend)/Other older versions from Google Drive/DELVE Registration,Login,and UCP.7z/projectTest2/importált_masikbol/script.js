document.getElementById("register").onsubmit = function(event) {
    if (document.getElementById("password").value !== document.getElementById("password2").value) {
        alert("Both passwords need to be the same!");
        event.preventDefault(); // Megakadályozza a form elküldését
    }
};

/*
function showAlert() {
    // Létrehozzuk a div elemet
    const alertDiv = document.createElement('div');
    alertDiv.setAttribute('role', 'alert');
    alertDiv.className = 'alert alert-success';

    // Létrehozzuk az SVG elemet
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('class', 'h-6 w-6 shrink-0 stroke-current');
    svg.setAttribute('fill', 'none');
    svg.setAttribute('viewBox', '0 0 24 24');

    // Létrehozzuk a path elemet
    const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    path.setAttribute('stroke-linecap', 'round');
    path.setAttribute('stroke-linejoin', 'round');
    path.setAttribute('stroke-width', '2');
    path.setAttribute('d', 'M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z');

    // Összeállítjuk az SVG-t
    svg.appendChild(path);
    alertDiv.appendChild(svg);

    // Létrehozzuk a span elemet
    const span = document.createElement('span');
    span.textContent = 'Your account has been created! Now you can log in!';
    alertDiv.appendChild(span);

    // Hozzáadjuk a divet a dokumentumhoz, például a body végére
    document.body.appendChild(alertDiv);
}
*/