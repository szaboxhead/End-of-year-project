<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DELVE Registration</title>
    <link rel="stylesheet" href="./css/style.css">
    <script async src="./importált_masikbol/script.js"></script>
</head>
<body>
  <div class="wrapper">
    <form action="register.php" method="post" id="register">
    <h2>Register an account </h2>
    <div class="input-field">
        <input type="text" name="username" id="username" required>
        <label for="username">Username:</label>
        </div>
      <div class="input-field">
        <input type="email" name="email" id="email" required>
        <label for="email">Email:</label>
        </div>
      <div class="input-field">
        <input type="password" name="password" id="password" required>
        <label for="password">Password:</label>
        </div>
      <div class="input-field">
        <input type="password" name="password2" id="password2" required>
        <label for="password2">Password Again:</label>
      </div>    
      <div id="tos">
      <label for="agree">  
      <input type="checkbox" name="agree" class="agree" id="box" value="checked" required/> 
        <p id="white-text">I agree with the            
        <a href="./importált_masikbol/TOS.html" title="term of services">term of services</a></p>
        </label>
      </div>

    <button type="submit" id="button">Register</button>
    <div class="register">
        <p>You already have an account? <a href="login.php">Log in here</a></p>
      </div>
    </form>
  </div>
</body>
</html>
