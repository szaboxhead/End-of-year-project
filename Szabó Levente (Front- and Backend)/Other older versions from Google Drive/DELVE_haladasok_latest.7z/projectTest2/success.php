<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Succesful Registration</title>
    <link rel="stylesheet" href="./css/welcomeStyle.css">
    <link rel="shortcut icon" href="../favico2.png" type="image/png">

</head>
<body>
    <img src="./img/delve_logo.png" alt="DELVE" class="logo">
    <h1>Succesful Registration</h1>
    <p id="thanks">Thank you for the registration, now you can log in.</p>
    <a href="login.php" id="login">Take me to the login page >>></a>
    
</body>
</html>
