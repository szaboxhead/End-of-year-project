<?php
require 'db.php';
$errors = [];

// Ellenőrizzük, hogy POST kérés érkezett-e
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    // Ellenőrzés, hogy a felhasználónév és az e-mail cím egyedi-e
    $pdo = db();

    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = :username OR email = :email");
    $stmt->execute(['username' => $username, 'email' => $email]);
    
    if ($stmt->fetch()) {
        $errors[] = "A felhasználónév vagy az e-mail cím már létezik!";
    }

    // Jelszó hash-elése
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    if (empty($errors)) {
        // Felhasználó regisztrálása
        $stmt = $pdo->prepare("INSERT INTO users (username, email, password) VALUES (:username, :email, :password)");
        $stmt->execute(['username' => $username, 'email' => $email, 'password' => $hashedPassword]);
        
        header("Location: success.php");
        exit;
    }
}

// Hibák megjelenítése
foreach ($errors as $error) {
    echo "<p style='color: red;'>$error</p>";
}
?>
